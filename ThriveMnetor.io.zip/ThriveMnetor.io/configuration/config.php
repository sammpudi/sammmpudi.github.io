<?php

$connection = mysqli_connect("localhost", "root","","users") or die("Could not Connect")

?>